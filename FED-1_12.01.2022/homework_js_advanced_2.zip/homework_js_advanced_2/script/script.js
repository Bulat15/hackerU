const wordElement = document.querySelector('#word-form');

let cardValues = [];

rootElem = document.querySelector("#cards")

class Post{

    constructor(word,text){
        this.word = word;
        this.text = text;
        this.like = false;
    }
    get(config){
        const {tag, classList} = config;
        const rootElem = document.createElement(tag);
        classList && rootElem.classList.add(...classList);
        const wordElem = document.createElement('h2');
        const textElem = document.createElement('p');
        const closeElem = document.createElement('div');
        rootElem.append(wordElem,textElem,closeElem);
        wordElem.innerText = this.word;
        textElem.innerText = this.text;
        closeElem.innerText = 'Х';
        closeElem.classList.add('close');
       return rootElem;
    }

    changeLike(){
        this.like = !this.like;
    }


}
wordElement.addEventListener('submit', function (event) {
	event.preventDefault();
	const postsPost = new Post(this.word.value,this.text.value);
    const postPostPost = postsPost.get({tag:"div",classList:['card']});
    rootElem.append(postPostPost);
});
