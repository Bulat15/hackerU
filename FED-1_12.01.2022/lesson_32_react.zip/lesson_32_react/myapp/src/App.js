
function App() {
  return (
    <div>Привет</div>
  );
}

export default App;
